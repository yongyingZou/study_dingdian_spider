from .sql import Sql
from test_01.items import Test01Item

class DinddianPipeline(object):
    def process_item(self, item, spider):
        # if isinstance(item, Test01Item):
        #     name_id = item['xs_name']
        #     ret = Sql.select_name(name_id)
        #     if ret[0] == 1:
        #         print('存在')
        #         pass
        # else:
            xs_name = item['name']
            xs_author = item['author']
            category = item['category']
            Sql.insert_dd_name(xs_name, xs_author, category)
            print('开始保存标题')
