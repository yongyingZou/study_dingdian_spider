
import re
import scrapy  # 导入scrapy包
from bs4 import BeautifulSoup
from scrapy.http import Request  ##一个单独的request的模块，需要跟进URL的时候，需要用它
from test_01.items import Test01Item  ##这是我定义的需要保存的字段，（导入dingdian项目中，items文件中的DingdianItem类）


class Myspider(scrapy.Spider):
    name = 'test_spider'
    allowed_domains = ['23us.so']
    first_url = 'http://www.23us.so/list/'
    last_url = '.html'

    def start_requests(self):
        for i in range(1, 11):
            url = self.first_url + str(i) + '_1' + self.last_url
            yield Request(url, self.parse)
        yield Request('http://www.23us.com/full/1', self.parse)

    def parse(self, response):
        max_num = BeautifulSoup(response.text, 'lxml').find('div', class_='pagelink').find_all('a')[-1].get_text()
        bashurl = str(response.url)[:-7]
        for num in range(1, int(max_num) + 1):
            url = bashurl + '_' + str(num) +self.last_url
            yield Request(url, callback=self.get_name)

    def get_name(self, response):
        soup = BeautifulSoup(response.text, 'lxml')
        tds = soup.find_all('tr', bgcolor="#FFFFFF")
        for td in tds:
            novel_name = td.find('a').get_text()
            novel_url = td.find('a')['href']
            yield Request(novel_url, callback=self.get_chapterurl, meta={'name':novel_name, 'url': novel_url})

    def get_chapterurl(self, response):
        item = Test01Item()
        item['name'] = str(response.meta['name'])
        item['novelurl'] = response.meta['url']
        category = BeautifulSoup(response.text, 'lxml').find('table').find('a').get_text()
        author = BeautifulSoup(response.text, 'lxml').find('table').find_all('td')[1].get_text()
        item['category'] = str(category).replace('/', '')
        item['author'] = str(author).replace('\xa0', '')#\xa0 就是去除问号，也就是空格，这样输出的字符才是不会带符号的文字
        return item
    

        

